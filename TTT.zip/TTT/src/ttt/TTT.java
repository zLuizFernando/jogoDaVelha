/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ttt;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author lenovoa
 */
public class TTT {
     static String[][] m = new String[3][3];//criei uma matriz global 
    
    public static void main(String[] args) {
        Menu();// chamei a funcao menu que depois que o usuario escolher um
              //  modo ira chama as outras 
    }
    
    static String[][] inicializarTabuleiro(String[][] m){
         m = new String [][]{{"n","n","n"},
                             {"n","n","n"},
                             {"n","n","n"}};
        
        //populei a matriz com "n"
        
        return m;//retorno a matriz populada
    }
    static void ImprimirTabuleiro(String[][] m){//Funcao sem retorno
        for(int i = 0; i < m.length;i++){
            for(int j = 0; j < m.length;j++){
                System.out.printf("   " + m[i][j]);
            }
            System.out.println("\n");
        }// Essa funcao so imprrime a Matriz com seus valores 
    }
    static int leiaCoordenadaLinha(){
        Scanner scan = new Scanner(System.in);// chamaei o metodo Scanner para
        int linha;                            // pega a resposta do usuario
        System.out.print("Digite a linha:");
        linha = scan.nextInt();
        while(linha < 0 || linha > 2){
            System.out.println("Valor Invalido!Tente Novamente.");
            System.out.print("Digite a linha:");
            linha = scan.nextInt();
        }
        //emquanto a resposta do usuario for menor ou maior que o disponivel o 
        //programa ira continuamente pedindo um valor disponivel para o usuario 
        
        return linha;// retorno uma variavel int com o valor da linha 
    }
    static int leiaCoordenadaColuna(){
        Scanner scan = new Scanner(System.in);//chamei o metodo Scanner para
        int coluna;                           //ler a resposta do usuario
        System.out.print("Digite a Coluna:");
        coluna = scan.nextInt();
        while(coluna < 0 || coluna > 2){
            System.out.println("Valor Invalido!Tente Novamente.");
            System.out.print("Digite a Coluna:");
            coluna = scan.nextInt();
        }//enquanto a resposta do usuario nao for valida o programar ira 
         //fica pedindo uma nova resposta que ate que seja valida 
         
        return coluna;//retorno uma variavel int com o valor da coluna
    }
    
    static boolean posicaoValida(int linha, int coluna, String[][] m){
        boolean verificacao = false;
        for(int i = 0; i < m.length;i++){
            for(int j = 0; j < m.length;j++){
                if(m[i][j] == m[linha][coluna]){
                   verificacao = true;
                   //aqui ele ira percorrer a matriz vendo se na posicao da 
                   //matriz esta disponivel para joga ou ja foi preenchida.
                   //se tiver livre a variavel verificacao recebe "true"
                }else if(m[linha][coluna] == "X" || m[linha][coluna] == "O"){
                   verificacao = false;
                }//se a posicao da matriz ja estiver preenchida com "X" ou "O"
                //entao a variavel verificacao recebe "false"
            }
        }
        return verificacao;//retorna a variavel verificacao
    }
    static String verificaVencedor(int jogadas, String[][] m){
        String[] v = new String[8];
        //criei um vetor para guardar a soma das linhas com as colunas da matriz
        //para depois conparar e saber o vencedor
        
        String vencedor = null;// essa variavel começa com nada amarzenado"null"
        
        if(jogadas % 9 == 0){//Se o valor de jogadas for multiplo de 9 entao 
                             //é empate 
          System.out.println("EMPATE\n");
          vencedor = "EMPATE";// variavel receve "EMPATE"
        }
        v[0] = m[0][0] + m[0][1] + m[0][2];
        //vetor esta somando a linha 0 com coluna 0, linha 0 coluna 1, 
        //linha 0 e coluna 2  
        v[1] = m[1][0] + m[1][1] + m[1][2];
        //vetor esta somando a linha 1 com coluna 0, linha 1 com coluna 1, 
        //linha 1 com coluna 2
        v[2] = m[2][0] + m[2][1] + m[2][2];
        //vetor esta somando a linha 2 com coluna 0, linha 2 com coluna 1,
        //linha 2 com coluna 2
        v[3] = m[0][0] + m[1][0] + m[2][0];
        //vetor esta somando a linha 0 com coluna 0, linha 1 com coluna 0, 
        //linha 2 com coluna 0 
        v[4] = m[0][1] + m[1][1] + m[2][1];
        //vetor esta somando a linha 0 com coluna 1, linha 1 com coluna 1,
        //linha 2 com coluna 1
        v[5] = m[0][2] + m[1][2] + m[2][2];
        //vetor esta somando a linha 0 com coluna 2, linha 1 com coluna 2,
        //linha 2 com coluna 2
        v[6] = m[0][0] + m[1][1] + m[2][2];
        //vetor esta somando a linha 0 com coluna 0, linha 1 com coluna 1,
        //linha 2 com coluna 2
        v[7] = m[0][2] + m[1][1] + m[2][0];
        //vetor esta somando a linha 0 com coluna 2, linha 1 com coluna 1,
        //linha 2 com coluna 0
        
        for(int i = 0; i < v.length;i++){
            if(v[i].equals ("XXX")){//se o vetor na posicao(i) for igual a "XXX"
              vencedor = "Jogador 1";// entao a variavel recebe "Jogador 1"
            }else if(v[i].equals("OOO")){
              vencedor = "Jogador 2";//se o vetor na posicao(i)for igual a "OOO"
            }                        // entao a variavel recebe "Jogador 2"
        }
        return vencedor;//retorna variavel vencedor
    }
    static void jogar(int linha, int coluna, String[][] m, String jogador){
        if(linha == 0 && coluna == 0){
           //se linha for igual a 0 e coluna igual a 0, entao a matriz recebe a 
           //variavel jogador
           m[0][0] = jogador;
        }else if(linha == 0 && coluna == 1){
            //se linha for igual a 0 e coluna igual a 1, entao a matriz recebe a 
           //variavel jogador
           m[0][1] = jogador;
        }else if(linha == 0 && coluna == 2){
            //se linha for igual a 0 e coluna igual a 0, entao a matriz recebe a 
           //variavel jogador
           m[0][2] = jogador;
        }else if(linha == 1 && coluna == 0){
            //se linha for igual a 1 e coluna igual a 0, entao a matriz recebe a 
           //variavel jogador
           m[1][0] = jogador;
        }else if(linha == 1 && coluna == 1){
            //se linha for igual a 1 e coluna igual a 1, entao a matriz recebe a 
           //variavel jogador
           m[1][1] = jogador;
        }else if(linha == 1 && coluna == 2){
            //se linha for igual a 1 e coluna igual a 2, entao a matriz recebe a 
           //variavel jogador
           m[1][2] = jogador;
        }else if(linha == 2 && coluna == 0){
            //se linha for igual a 2 e coluna igual a 0, entao a matriz recebe a 
           //variavel jogador
           m[2][0] = jogador;
        }else if(linha == 2 && coluna == 1){
            //se linha for igual a 2 e coluna igual a 1, entao a matriz recebe a 
           //variavel jogador
           m[2][1] = jogador;
        }else if(linha == 2 && coluna == 2){
            //se linha for igual a 2 e coluna igual a 2, entao a matriz recebe a 
           //variavel jogador
           m[2][2] = jogador;
        } 
    }
    static void modoJogador(){
        m = inicializarTabuleiro(m);
        //A matriz m global recebe a funcao inicializar Tabuleiro com ela de
        //parametro
        boolean venceu = false;
        boolean verificacao = false;
        int linha, coluna;
        String vencedor = null;
        int jogada = 0, rodadas = 0;
        
            System.out.println("--- Jogo da Velha ---\n");
            ImprimirTabuleiro(m);//funcao imprimir tabuleiro com  m de parametro
                                //que é a matriz global, ira imprimir a matriz     
            while(true){         
               //fiz esse laço while infinito para que ele continue rodando até
               // que tenha um vencedor
                do{
                
                System.out.println("Jogador 1");
                linha = leiaCoordenadaLinha();
                //variavel linha recebe a função leiaCooedenadaLinha
                coluna = leiaCoordenadaColuna();
                //variavel coluna recebe a função leiaCooedenadaColuna
                verificacao = posicaoValida(linha, coluna, m);
                //variavel verificacao recebe a função posicaoValida com a 
                //linha, coluna e matriz global como parametro
                
                while(verificacao == false){
                    // enquanto variavel verificacao for false ira rodada os 
                    //comandos a baixo
                    System.out.println("Jogada Invalida! Tente Novamente.");
                    ImprimirTabuleiro(m);
                    //funcao imprimir tabuleiro com a matriz como parametro
                    //para imprimir o tabuleiro
                    System.out.println("Jogador 1");
                    linha = leiaCoordenadaLinha();
                    //variavel linha recebe a função leiaCooedenadaLinha
                    coluna = leiaCoordenadaColuna();
                    //variavel coluna recebe a função leiaCooedenadaColuna
                    verificacao = posicaoValida(linha, coluna, m);
                    //variavel verificacao recebe a função posicaoValida com a 
                    //linha, coluna e matriz global como parametro
                }
                jogar(linha, coluna, m, "X");
                //a funcao "Jogar" é chamada e rebebe as variaveis linha, coluna,
                //matriz e "X" como parametro 
                jogada = 1;
                //variavel "jogada" recebe 1
                
            }while(jogada == 0);//esse do-while ira parar se a jogada do usuario
                               //estiber correta e a variavel "jogada" estiver 1
            rodadas++;
            //a variavel rodadas serve para conta contas jogadas ja foram feitas
            //incremento 1 a cada jogada
            jogada = 0;
            //variavel jogada volta a ser 0 
            ImprimirTabuleiro(m);
            //funcao imprimir tabuleiro com a matriz global como parametro
            //para imprimir o tabuleiro
            vencedor = verificaVencedor(rodadas, m);
            ///A variavel "vencedor" chama e recebe a funcao verifica Vencedor
            //com a variavel rodadas e a matriz global de parametro
            if(vencedor == "Jogador 1"){
               //se a variavel vencedor for igual a "Jogador 1" entao a ira
               //parar o laço de repetição infinito com o break
               break;
            }
            if(vencedor == "EMPATE"){
                //se variavel "vencedor" for igual a "EMPATE" então o laço de 
                //repetição não ira quebrar e sera feito os comandos a baixo
                m = inicializarTabuleiro(m);
                //A matriz m global recebe a funcao inicializar Tabuleiro com 
                //ela de parametro, para reinicializar o tabuleiro
                ImprimirTabuleiro(m);
                //funcao imprimir tabuleiro com  m de parametro
                //que é a matriz global, ira imprimir a matriz
                vencedor = verificaVencedor(rodadas, m);
                //A variavel "vencedor" chama e recebe a funcao verificaVencedor
                //com a variavel rodadas e a matriz global de parametro
            }
            
            do{
                System.out.println("Jogador 2");
                linha = leiaCoordenadaLinha();
                //variavel linha recebe a função leiaCooedenadaLinha
                coluna = leiaCoordenadaColuna();
                //variavel coluna recebe a função leiaCooedenadaColuna
                verificacao = posicaoValida(linha, coluna, m);
                //variavel verificacao recebe a função posicaoValida com a 
                //linha, coluna e matriz global como parametro
                
                while(verificacao == false){
                    // enquanto variavel verificacao for false ira rodada os 
                    //comandos a baixo
                    System.out.println("Jogada Invalida! Tente Novamente.");
                    ImprimirTabuleiro(m);
                    //funcao imprimir tabuleiro com a matriz como parametro
                    //para imprimir o tabuleiro
                    System.out.println("Jogador 2");
                    linha = leiaCoordenadaLinha();
                    //variavel linha recebe a função leiaCooedenadaLinha
                    coluna = leiaCoordenadaColuna();
                    //variavel coluna recebe a função leiaCooedenadaColuna
                    verificacao = posicaoValida(linha, coluna, m);
                    //variavel verificacao recebe a função posicaoValida com a 
                    //linha, coluna e matriz global como parametro
                }
                jogar(linha, coluna, m, "O");
                //a funcao "Jogar" é chamada e rebebe as variaveis linha, coluna,
                //matriz e "O" como parametro 
                jogada = 1;
                //variavel "jogada" recebe 1
                
            }while(jogada == 0);//esse do-while ira parar se a jogada do usuario
                               //estiber correta e a variavel "jogada" estiver 1
            
            rodadas++;
            //a variavel rodadas serve para conta contas jogadas ja foram feitas
            //incremento 1 a cada jogada
            jogada = 0;
            //variavel jogada volta a ser 0 
            ImprimirTabuleiro(m);
            //funcao imprimir tabuleiro com a matriz global como parametro
            //para imprimir o tabuleiro
            vencedor = verificaVencedor(rodadas, m);
            ///A variavel "vencedor" chama e recebe a funcao verifica Vencedor
            //com a variavel rodadas e a matriz global de parametro
            
            if(vencedor == "Jogador 2"){
               //se a variavel vencedor for igual a "Jogador 2" então a ira
               //parar o laço de repetição infinito com o break
               break;
            }
            if(vencedor == "EMPATE"){
                //se variavel "vencedor" for igual a "EMPATE" então o laço de 
                //repetição não ira quebrar e sera feito os comandos a baixo
                m = inicializarTabuleiro(m);
                //A matriz m global recebe a funcao inicializar Tabuleiro com 
                //ela de parametro, para reinicializar o tabuleiro
                ImprimirTabuleiro(m);
                //funcao imprimir tabuleiro com a matriz global como parametro
                //para imprimir o tabuleiro
                vencedor = verificaVencedor(rodadas, m);
                //A variavel "vencedor" chama e recebe a funcao verificaVencedor
                //com a variavel rodadas e a matriz global de parametro 
            }
        }
        
        if(vencedor == "Jogador 1" || vencedor == "Jogador 2"){
           // se a "Vencedor" for igual a "Jogador 1" ou igual a "Jogador 2 "
           // então imprimir o ganhador
           System.out.println("O Ganhador é " + vencedor);
        }
    }
    static void modoFacil(){
        String vencedor = null;
        //a variavel vencedor começa vazia 
        int jogada = 0, rodadas = 0;
        m = inicializarTabuleiro(m);
        //A matriz m global recebe a funcao inicializar Tabuleiro com 
        //ela de parametro, para reinicializar o tabuleiro
        System.out.println("--- Jogo da Velha ---\n");
        ImprimirTabuleiro(m);
        //funcao imprimir tabuleiro com a matriz global como parametro
        //para imprimir o tabuleiro
        while(true){
            //fiz esse laço while infinito para que ele continue rodando até
            // que tenha um vencedor
            do{
                jogadaUsuario();
                //a funcao jogadaUsuario é chamada para ser executada 
                jogada = 1;
                //variavel "jogada" recebe 1
                
            }while(jogada == 0);//esse do-while ira parar se a jogada do usuario
                               //estiber correta e a variavel "jogada" estiver 1
            
            rodadas++;
            //a variavel rodadas serve para conta contas jogadas ja foram feitas
            //incremento 1 a cada jogada
            jogada = 0;
            //jogada volta a ser 0
            vencedor = verificaVencedor(rodadas, m);
            //A variavel "vencedor" chama e recebe a funcao verificaVencedor
            //com a variavel rodadas e a matriz global de parametro 
            
            if(vencedor == "Jogador 1"){
               //se a variavel "vencedor" for igual a "Jogador 1" 
               ImprimirTabuleiro(m);
               //funcao imprimir tabuleiro com a matriz global como parametro
               //para imprimir o tabuleiro
               break;//quebra o laço de repetição
            }
            if(vencedor == "EMPATE"){
                //se a variavel "vencedor" for igual a "EMPATE" 
                m = inicializarTabuleiro(m);
                //A matriz m global recebe a funcao inicializar Tabuleiro com 
                //ela de parametro, para reinicializar o tabuleiro
                ImprimirTabuleiro(m);
                //funcao imprimir tabuleiro com a matriz global como parametro
                //para imprimir o tabuleiro
                vencedor = verificaVencedor(rodadas, m);
                //A variavel "vencedor" chama e recebe a funcao verificaVencedor
                //com a variavel rodadas e a matriz global de parametro 
            }
            
            do{
                jogadaMaquinaFacil();
                //A função jogadaMaquinaFacil é chamada para ser executada
                jogada = 1;
                //variavel jogada recebe 1
                
            }while(jogada == 0);//esse do-while ira parar se a jogada do usuario
                               //estiber correta e a variavel "jogada" estiver 1
           
            rodadas++;
            //a variavel rodadas serve para conta contas jogadas ja foram feitas
            //incremento 1 a cada jogada
            jogada = 0;
            //jogada volta a ser 0
            ImprimirTabuleiro(m);
            //funcao imprimir tabuleiro com a matriz global como parametro
            //para imprimir o tabuleiro
            vencedor = verificaVencedor(rodadas, m);
            //A variavel "vencedor" chama e recebe a funcao verificaVencedor
            //com a variavel rodadas e a matriz global de parametro 
            
            if(vencedor == "Jogador 2"){
               //se a variavel "vencedor" for igual a "Jogador 2" 
               vencedor = "Maquina"; 
               //variavel "vencedor" recebe "Maquina"
               break;//quebra o laço de repetição
            }
            if(vencedor == "EMPATE"){
                //se a variavel "vencedor" for igual a "EMPATE" 
                m = inicializarTabuleiro(m);
                //A matriz m global recebe a funcao inicializar Tabuleiro com 
                //ela de parametro, para reinicializar o tabuleiro
                ImprimirTabuleiro(m);
                //funcao imprimir tabuleiro com a matriz global como parametro
                //para imprimir o tabuleiro
                vencedor = verificaVencedor(rodadas, m);
                //A variavel "vencedor" chama e recebe a funcao verificaVencedor
                //com a variavel rodadas e a matriz global de parametro 
            }
        }
        if(vencedor == "Jogador 1" || vencedor == "Maquina"){
            // se a "Vencedor" for igual a "Jogador 1" ou igual a "Maquina"
           // então imprimir o ganhador
           System.out.println("O Ganhador é " + vencedor);
        }
    }
    static void jogadaUsuario(){
        int linha = leiaCoordenadaLinha();
        //variavel linha recebe a função leiaCooedenadaLinha
        int coluna = leiaCoordenadaColuna();
        //variavel coluna recebe a função leiaCooedenadaColuna
        boolean verificacao = posicaoValida(linha, coluna, m);
        //variavel verificacao recebe a função posicaoValida com a 
        //linha, coluna e matriz global como parametro
        
        while(verificacao == false){
            // enquanto variavel verificacao for false ira rodada os 
            //comandos a baixo
            System.out.println("Jogada Invalida! Tente Novamente.");
            ImprimirTabuleiro(m);
            //funcao imprimir tabuleiro com a matriz como parametro
            //para imprimir o tabuleiro 
            linha = leiaCoordenadaLinha();
            //variavel linha recebe a função leiaCooedenadaLinha
            coluna = leiaCoordenadaColuna();
            //variavel coluna recebe a função leiaCooedenadaColuna
            verificacao = posicaoValida(linha, coluna, m);
            //variavel verificacao recebe a função posicaoValida com a 
            //linha, coluna e matriz global como parametro
        }
        jogar(linha, coluna, m, "X");
        //a funcao "Jogar" é chamada e rebebe as variaveis linha, coluna,
        //matriz e "X" como parametro 
    }
    static void jogadaMaquinaFacil(){
        //aprendi a usar o metodo random na disciplina de projeto integrador
        Random aleatorio = new Random();
        //chamei o metodo Random e dei o nome de aleatorio 
        int linha = aleatorio.nextInt(2 + 1);
        //variavel "linha" recebe o metodo "aleatorio" que ira ser um numero
        //entre 0 e 2
        int coluna = aleatorio.nextInt(2 + 1);
        //variavel "coluna" recebe o metodo "aleatorio" que ira ser um numero
        //entre 0 e 2
        boolean verificacao = posicaoValida(linha, coluna, m);
        //variavel verificacao recebe a função posicaoValida com a 
        //linha, coluna e matriz global como parametro
        while(verificacao == false){
            // enquanto variavel verificacao for false ira rodada os 
            //comandos a baixo
            linha = aleatorio.nextInt(2 + 1);
            //variavel "linha" recebe o metodo "aleatorio" que ira ser um numero
            //entre 0 e 2
            coluna = aleatorio.nextInt(2 + 1);
            //variavel "coluna" recebe o metodo "aleatorio" que ira ser um numero
            //entre 0 e 2
            verificacao = posicaoValida(linha, coluna, m);
            //variavel verificacao recebe a função posicaoValida com a 
            //linha, coluna e matriz global como parametro
        }
        jogar(linha, coluna, m, "O");
        //a funcao "Jogar" é chamada e rebebe as variaveis linha, coluna,
        //matriz e "O" como parametro 
    }
    static void Instrucoes(){
        //so usei println para fornecer as instruções
        System.out.println("                ------- Instruções -------  ");
        System.out.println("O joga da velha tem os 2 modos que são, jogador contra jogador e");
        System.out.println("jogador contra maquina. para joga de forma certo o usuario tera ");
        System.out.println("que escolher entre 0, 1, 2 para escolher a linha e coluna desejada.\n");
    }
    static void Menu(){
        //chamei o metodo Scanner e dei o nome de scan para poder receber a 
        //digitação do usuario
        Scanner scan = new Scanner(System.in);
        int op;
        
        do{
            System.out.println("      --- MENU ---         ");
            System.out.println("1 - Jogador VS Jogador");
            System.out.println("2 - Jogador VS Maquina(Facil)");
            System.out.println("3 - Instruções");
            System.out.println("4 - Sair");
            op = scan.nextInt();
            //variavel "op" recebe a digitação do usuario
        
        while(op < 1 || op > 4){
            //enquanto a variavel "op" receber um numero que seja menor que 1 e
            //maior que 4, o programa ira repetiver o menu
            System.out.println("Valor Invalido! Tente Novamente.\n");
            System.out.println("      --- MENU ---         ");
            System.out.println("1 - Jogador VS Jogador");
            System.out.println("2 - Jogador VS Maquina(Facil)");
            System.out.println("3 - Instruções");
            System.out.println("4 - Sair");
            op = scan.nextInt();
            //variavel "op" recebe a digitação do usuario
        }
        
        switch(op){
            case 1: //caso seja 1
                modoJogador();
                //a função modoJogador é chamada para ser executada e quando 
                //acabar as suas funções ele voltara para o menu
            case 2://caso seja 2
                modoFacil();
                //a função modoFacil é chamada para ser executada e quando 
                //acabar as suas funções ele voltara para o menu
            case 3://caso seja 3
                Instrucoes();
                //a função intruções é chamada para ser executada e quando 
                //acabar as sua função ele voltara para o menu
            case 4://caso seja 4
                System.out.println("Jogo Encerrado.");
                //o programar ira enviar para tela "Jogo Encerrado" e ira parar
                //finalizara o jogo
        }
        
        }while(!(op == 4));
        //esse do-while ira repetir o menu enquanto o usuario não digita digit 4                   
        
    }
}